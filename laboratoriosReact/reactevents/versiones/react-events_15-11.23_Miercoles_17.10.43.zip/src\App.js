import React, { Component } from "react";
// [16.47] Primera Versi�n
// [16.59] Evento Onclick
// [17.05] Evento Onclick [onMouseup onMouseDown]
// [17.10] Evento Onclick Counter



export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            message: "Ready",
            counter:0
        }
    }
    handleEvent(event) {
     /* console.log("handleEvent method invoked")
        this.setState({ message: `Event: ${event.type}` })
     */
     /*   if (event.type === "mousedown") {
            this.setState({ message: "Down" })
          } else {
            this.setState({ message: "Up" })
          }
     */

        this.setState({ counter: this.state.counter + 1 },
            () => this.setState({message:`${event.type}: ${this.state.counter}`})
        )
    }

    render() {
        return (
            <div className="m-2">
                <div className={`h4 bg-primary text-white text-center p-2`} >
                    {this.state.message}

                </div>
                <div className="text-center">
                    <button className="btn btn-primary"
                            onClick={(event) => this.handleEvent(event)}>Click Me!
                    </button>
                </div>
            </div>
        )
    }
}

/* 
Cuando Lanzamos un evento, recibimos un [OBJECT] que tiene (propiedades y m�todos)
    target: Indica cual es el objeto que ha levantado el evento 
    type: [string] que indica el tipo de evento que se ha disparado
    persist(): metodo para que el evento perdure en sucesivas llamadas (si trabajo de manera asincrona, que no son inmediatas, tiene que durar hasta que la petici�n as�crona se complete)
*/