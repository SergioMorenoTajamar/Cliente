import React, { Component } from "react";
// [16.47] Primera Versi�n

export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            message: "Ready"
        }
    }
    handleEvent(event) {
        // console.log("handleevent method invoked")
        //this.setState({message:"clicked!"})
        this.setState({message:`event: ${event.type}`})
    }

    render() {
        return (
            <div className="m-2">
                <div className={`h4 bg-primary text-white text-center p-2`} >
                    {this.state.message}
                    
                </div>
                <div className="text-center">
                    <button className="btn btn-primary"
                        onClick={(event) => this.handleEvent(event)}>Click me!
                    </button>
                </div>
            </div>
        )
    }
}

/* 
Cuando Lanzamos un evento, recibimos un [OBJECT] que tiene (propiedades y m�todos)
    target: Indica cual es el objeto que ha levantado el evento 
    type: [string] que indica el tipo de evento que se ha disparado
    persist(): metodo para que el evento perdure en sucesivas llamadas (si trabajo de manera asincrona, que no son inmediatas, tiene que durar hasta que la petici�n as�crona se complete)
*/