import { Component } from "react";


export class Editor extends Component {
    render() {
        return (
            <div className="h5 bg-info text-white p-2">
            Form Will go here

            </div>
        )
    }

}