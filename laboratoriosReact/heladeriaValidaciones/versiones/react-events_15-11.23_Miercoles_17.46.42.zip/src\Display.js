import { Component } from "react";

// Ni siquiera lo hemos usado: [17.45]

export class Display extends Component {

        formatValue = (data) => Array.isArray(data) ? data.join(", "):data.toString()
    render() {
        {/* determina qu� le ha venido [array] � [string] */ }

        let keys = Object.keys(this.props.data)
        {/* Si no vienen datos */ }
        if (keys.length === 0) {
            return <div className="h5 bg-secondary p-2 text-white">No data
            </div>

            {/* Si vienen datos */ }
        } else {
            return <div clasName="container-fluid bg-secondary p-2">
                {/* Por cada una de las claves*/}
                {keys.map(key => 
                    <div key={key} className="row h5 text-white">
                        <div className="col">{key}</div>
                        <div className="col">
                            {this.formatValue(this.props.data[key])}
                        </div>
                    </div>
                )
        }
            </div >
        }
}

}
/*
    var arr = ['a','b','c']
    console.log(Object.keys(arr)) --> ['0','1','2']
*/