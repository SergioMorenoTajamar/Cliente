import React, { Component } from "react";
// [16.47] Primera Versi�n
// [16.59] Evento Onclick
// [17.05] Evento Onclick [onMouseup onMouseDown]
// [17.10] Evento Onclick Counter (Manejador de eventos)
// [17.23] Evento Onclick Counter + theme



export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            message: "Ready",
            counter: 0,
            theme:"secondary"
        }
    }
    handleEvent(event,newTheme) {
        // Espera la respuesta para poder manejar la respuesta.
        event.persist(); 

     /* console.log("handleEvent method invoked")
        this.setState({ message: `Event: ${event.type}` })
     */
     /*   if (event.type === "mousedown") {
            this.setState({ message: "Down" })
          } else {
            this.setState({ message: "Up" })
          }
     */

        this.setState({ counter: this.state.counter + 1, theme: newTheme },
            () => this.setState({message:`${event.type}: ${this.state.counter}`})
        )
    }

    render() {
        return (
            <div className="m-2">
                <div className={`h4 bg-${this.state.theme} text-white text-center p-2`} >
                    {this.state.message}

                </div>
                <div className="text-center">
                    <button className="btn btn-primary"
                        onClick={(event) => this.handleEvent(event,"primary")}
                    >Click Me!
                    </button>
                    <button className="btn btn-danger"
                        onClick={(event) => this.handleEvent(event,"danger")}
                    >Danger!
                    </button>
                </div>
            </div>
        )
    }
}

/* 
Cuando Lanzamos un evento, recibimos un [OBJECT] que tiene (propiedades y m�todos)
    target: Indica cual es el objeto que ha levantado el evento 
    type: [string] que indica el tipo de evento que se ha disparado
    persist(): metodo para que el evento perdure en sucesivas llamadas (si trabajo de manera asincrona, que no son inmediatas, tiene que durar hasta que la petici�n as�crona se complete)
*/