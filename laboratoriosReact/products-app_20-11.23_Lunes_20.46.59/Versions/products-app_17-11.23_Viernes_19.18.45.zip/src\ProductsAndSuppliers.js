import React, { Component } from "react";
import { ProductDisplay } from "./ProductDisplay";
import { Selector } from "./Selector";
import { SupplierDisplay } from "./SupplierDisplay";

export default class ProductsAndSuppliers extends Component {

    constructor(props) {
        super(props)
        this.state = {
            products: [
                {
                    id: 1, name: "Kayak",
                    category: "Watersports", price: 275
                },
                {
                    id: 2, name: "Lifejacket",
                    category: "Watersports", price: 48.95
                },
                { id: 3, name: "Soccer Ball", category: "Soccer", price: 19.50 }
            ],
            suppliers: [
                { id: 1, name: "Surf Dudes", city: "San Jose", products: ["Kayak", "Lifejacket"] },
                { id: 2, name: "Field Supplies", city: "New York", products: ["Soccer Ball"] },
            ]
        }
        this.idCounter = 100;
    }

    render() {
        return <div>
            <Selector>
                <ProductDisplay></ProductDisplay>
                <SupplierDisplay></SupplierDisplay>
            </Selector>
        </div>
    }
}