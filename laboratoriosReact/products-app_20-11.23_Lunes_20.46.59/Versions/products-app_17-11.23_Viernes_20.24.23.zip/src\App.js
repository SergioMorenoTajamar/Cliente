/*
[17-11.23]
[16.25] A�adido todos los componentes SupplierTable, SupplierTableRow, SupplierAddRow, SupplierAddTable, SupplierEditRow, SupplierEditTable, SupplierFilter, selector.js, ProductAndSuppliers

{revisar context provider}


[17.18] Backup hasta ahora. 
*/

import {Component} from "react"
import ProductAndSuppliers from "./ProductsAndSuppliers"


export default class App extends Component {
    render() {
     return <ProductAndSuppliers></ProductAndSuppliers>
    }
}