import React, { Component } from "react";

export class ProductEditor extends Component {
    render() {
        return <div className="m-2">
            <div className="form-group">
                <label>ID</label>
                <input className="form-control" />
            </div>
            <div className="form-group">
                <label>NAME</label>
                <input className="form-control" />
            </div>
            <div className="form-group">
                <label>CATEGORY</label>
                <input className="form-control" />
            </div>
            <div className="form-group">
                <label>PRICE</label>
                <input className="form-control" />
            </div>
            <div className="form-group">
                <label></label>
                <button className="btn btn-primary m-1">Save</button>
                <button className="btn btn-secondary">Cancel</button>
            </div>

        </div>

    }


}