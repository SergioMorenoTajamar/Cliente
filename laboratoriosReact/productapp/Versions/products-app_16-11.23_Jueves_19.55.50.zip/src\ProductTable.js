import { Component } from "react";

export class ProductTable extends Component {
    render() {
        return <table>
            <thead>
                <tr colspan="5" className="bg-primary text-white text-center">Products</tr>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>CATEGORY</th>
                    <th>PRICE</th>
                </tr>
                <tr>
                    {/*mapear todos los elementos que haya en la base de datos*/}
                    {/*<ProductsTableRow>*/}
                </tr>
            </thead>

        </table>

    }

}