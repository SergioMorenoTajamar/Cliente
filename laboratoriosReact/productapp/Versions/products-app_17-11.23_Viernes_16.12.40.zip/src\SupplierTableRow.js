import { Component } from "react";


export class SupplierTableRow extends Component {

render() {
        return <tr>
            <td>ID</td>
            <td>NAME</td>
            <td>CITY</td>
            <td>LIST OF PRODUCTS</td>
            <td>
            <button>Edit</button>
            <button>Delete</button>

            </td>
            </tr>
            }
}